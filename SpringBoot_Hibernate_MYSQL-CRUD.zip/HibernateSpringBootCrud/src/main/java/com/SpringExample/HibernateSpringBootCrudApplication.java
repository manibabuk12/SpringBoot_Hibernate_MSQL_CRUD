package com.SpringExample;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.SpringExample.model.Employee;
import com.SpringExample.ropository.EmployeeRepository;

@SpringBootApplication
public class HibernateSpringBootCrudApplication implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(HibernateSpringBootCrudApplication.class, args);
	}

	@Autowired
	private EmployeeRepository employeeRepository;
	
	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		Employee employee = new Employee();
		employee.setFirstName("mani");
		employee.setLastName("kanda");
		employee.setEmail_id("mani4242@gmail.com");
		employeeRepository.save(employee);
	
		Employee employee1 = new Employee();
		employee1.setFirstName("vyshu");
		employee1.setLastName("kanda");
		employee1.setEmail_id("vyshu4242@gmail.com");
		employeeRepository.save(employee1);
		
		Employee employee2 = new Employee();
		employee2.setFirstName("durga");
		employee2.setLastName("kanda");
		employee2.setEmail_id("durga4242@gmail.com");
		employeeRepository.save(employee2);
	}

}
