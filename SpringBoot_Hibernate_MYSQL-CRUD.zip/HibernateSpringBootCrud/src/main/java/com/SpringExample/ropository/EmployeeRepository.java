package com.SpringExample.ropository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.SpringExample.model.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {

}
